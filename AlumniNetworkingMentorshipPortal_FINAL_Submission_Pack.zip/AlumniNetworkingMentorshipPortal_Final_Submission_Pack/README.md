# Alumni Networking & Mentorship Portal

Advanced Java CA-II project starter implementation.

## Stack
- Java 8+
- Apache Tomcat 9
- JSP + JSTL + EL
- JDBC
- MySQL
- Maven
- MVC
- HttpSession
- Background ReminderThread

## Maven layout
src/main/java contains Java sources and src/main/webapp contains JSP/web resources, following the standard Maven web-app layout.

## Setup
1. Create the MySQL database by running `database/schema.sql`.
2. Update database credentials in `src/main/java/com/alumni/portal/util/DBConnection.java`.
3. Open as a Maven project in Eclipse/NetBeans/IntelliJ.
4. Configure Tomcat 9.
5. Run `mvn clean package`.
6. Deploy the generated WAR to Tomcat.
7. Open `/AlumniNetworkingPortal/`.

## Important
This is a CA-II starter implementation. Before submission, replace all demo credentials/data, test every flow, add your actual screenshots, and verify the code against the version of Tomcat/JDK installed on your machine.

## Phase 2 implemented
- Student/alumni registration with role-specific profile data.
- Transactional user + profile creation using JDBC PreparedStatement.
- PBKDF2WithHmacSHA256 password hashing with per-password salt.
- Login verification using the stored PBKDF2 format.
- HttpSession-based authentication with 30-minute timeout.
- Authentication filter protecting dashboard/search/logout routes.
- Role-based dashboard routing through DashboardServlet.
- JSTL/EL used in the main authentication views instead of JSP scriptlets.

## Phase 4 — Mentorship Engine
Implemented:
- Mentorship topic retrieval.
- Student mentorship requests to an alumni with a selected topic and message.
- Alumni request review with accept/reject workflow.
- Alumni weekly availability management.
- Alumni bookable time-slot creation.
- Student booking of an available slot for an accepted request using a JDBC transaction.
- Session listing for both participants.
- Generated meeting-link placeholder for each booked session.
- PreparedStatement-based DAO operations and MVC Servlet/JSP flow.

The booking transaction updates the slot to BOOKED before creating the session and rolls back if either step fails, preventing a straightforward double-booking race.

Remaining before final submission: notification persistence/reminder thread integration, messaging, feedback, full validation/error handling, UI polish, live Tomcat/MySQL testing, screenshots, and final documentation.

## Phase 5 - Communication, Notifications & Multithreading
- Added `CommunicationDAO` and message/notification/feedback models.
- Added `/communication` for messages and notifications.
- Added `/session-action` for completing sessions and submitting student feedback.
- Implemented `ReminderThread` to periodically check sessions occurring within the next 24 hours and create `SESSION_REMINDER` notifications.
- `AppContextListener` starts the background thread when the web application initializes and stops it when the application is destroyed.
- Added JSP views using JSTL/EL for communication and notification data.
