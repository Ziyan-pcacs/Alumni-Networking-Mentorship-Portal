CREATE DATABASE IF NOT EXISTS alumni_portal;
USE alumni_portal;

CREATE TABLE users (
    user_id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    email VARCHAR(100) NOT NULL UNIQUE,
    password_hash VARCHAR(255) NOT NULL,
    role ENUM('STUDENT','ALUMNI') NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE courses (
    course_id INT PRIMARY KEY AUTO_INCREMENT,
    course_name VARCHAR(100) NOT NULL UNIQUE
);

CREATE TABLE industries (
    industry_id INT PRIMARY KEY AUTO_INCREMENT,
    industry_name VARCHAR(100) NOT NULL UNIQUE
);

CREATE TABLE companies (
    company_id INT PRIMARY KEY AUTO_INCREMENT,
    company_name VARCHAR(150) NOT NULL UNIQUE,
    location VARCHAR(100),
    website VARCHAR(255)
);

CREATE TABLE student_profiles (
    student_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL UNIQUE,
    course_id INT NOT NULL,
    division VARCHAR(20),
    current_year INT NOT NULL,
    graduation_year INT NOT NULL,
    bio TEXT,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (course_id) REFERENCES courses(course_id)
);

CREATE TABLE alumni_profiles (
    alumni_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL UNIQUE,
    industry_id INT NOT NULL,
    company_id INT,
    graduation_year INT NOT NULL,
    designation VARCHAR(100),
    experience_years DECIMAL(4,1),
    bio TEXT,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (industry_id) REFERENCES industries(industry_id),
    FOREIGN KEY (company_id) REFERENCES companies(company_id) ON DELETE SET NULL
);

CREATE TABLE skills (
    skill_id INT PRIMARY KEY AUTO_INCREMENT,
    skill_name VARCHAR(100) NOT NULL UNIQUE
);

CREATE TABLE alumni_skills (
    alumni_id INT NOT NULL,
    skill_id INT NOT NULL,
    proficiency VARCHAR(30),
    PRIMARY KEY (alumni_id, skill_id),
    FOREIGN KEY (alumni_id) REFERENCES alumni_profiles(alumni_id) ON DELETE CASCADE,
    FOREIGN KEY (skill_id) REFERENCES skills(skill_id) ON DELETE CASCADE
);

CREATE TABLE mentorship_topics (
    topic_id INT PRIMARY KEY AUTO_INCREMENT,
    topic_name VARCHAR(100) NOT NULL UNIQUE,
    description TEXT
);

CREATE TABLE mentorship_requests (
    request_id INT PRIMARY KEY AUTO_INCREMENT,
    student_id INT NOT NULL,
    alumni_id INT NOT NULL,
    topic_id INT NOT NULL,
    message TEXT NOT NULL,
    status ENUM('PENDING','ACCEPTED','REJECTED','COMPLETED') DEFAULT 'PENDING',
    requested_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (student_id) REFERENCES student_profiles(student_id) ON DELETE CASCADE,
    FOREIGN KEY (alumni_id) REFERENCES alumni_profiles(alumni_id) ON DELETE CASCADE,
    FOREIGN KEY (topic_id) REFERENCES mentorship_topics(topic_id)
);

CREATE TABLE alumni_availability (
    availability_id INT PRIMARY KEY AUTO_INCREMENT,
    alumni_id INT NOT NULL,
    day_of_week ENUM('MONDAY','TUESDAY','WEDNESDAY','THURSDAY','FRIDAY','SATURDAY','SUNDAY') NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    is_available BOOLEAN DEFAULT TRUE,
    FOREIGN KEY (alumni_id) REFERENCES alumni_profiles(alumni_id) ON DELETE CASCADE
);

CREATE TABLE session_time_slots (
    slot_id INT PRIMARY KEY AUTO_INCREMENT,
    availability_id INT NOT NULL,
    slot_date DATE NOT NULL,
    start_time TIME NOT NULL,
    end_time TIME NOT NULL,
    status ENUM('AVAILABLE','BOOKED','CANCELLED') DEFAULT 'AVAILABLE',
    FOREIGN KEY (availability_id) REFERENCES alumni_availability(availability_id) ON DELETE CASCADE
);

CREATE TABLE mentorship_sessions (
    session_id INT PRIMARY KEY AUTO_INCREMENT,
    request_id INT NOT NULL,
    slot_id INT NOT NULL UNIQUE,
    student_id INT NOT NULL,
    alumni_id INT NOT NULL,
    session_status ENUM('BOOKED','COMPLETED','CANCELLED') DEFAULT 'BOOKED',
    meeting_link VARCHAR(255),
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (request_id) REFERENCES mentorship_requests(request_id) ON DELETE CASCADE,
    FOREIGN KEY (slot_id) REFERENCES session_time_slots(slot_id),
    FOREIGN KEY (student_id) REFERENCES student_profiles(student_id),
    FOREIGN KEY (alumni_id) REFERENCES alumni_profiles(alumni_id)
);

CREATE TABLE messages (
    message_id INT PRIMARY KEY AUTO_INCREMENT,
    sender_id INT NOT NULL,
    receiver_id INT NOT NULL,
    session_id INT,
    message_text TEXT NOT NULL,
    sent_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    is_read BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (sender_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (receiver_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (session_id) REFERENCES mentorship_sessions(session_id) ON DELETE SET NULL
);

CREATE TABLE notification_types (
    notification_type_id INT PRIMARY KEY AUTO_INCREMENT,
    type_name VARCHAR(50) NOT NULL UNIQUE
);

CREATE TABLE notifications (
    notification_id INT PRIMARY KEY AUTO_INCREMENT,
    user_id INT NOT NULL,
    notification_type_id INT NOT NULL,
    message VARCHAR(255) NOT NULL,
    is_read BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES users(user_id) ON DELETE CASCADE,
    FOREIGN KEY (notification_type_id) REFERENCES notification_types(notification_type_id)
);

CREATE TABLE session_feedback (
    feedback_id INT PRIMARY KEY AUTO_INCREMENT,
    session_id INT NOT NULL UNIQUE,
    student_id INT NOT NULL,
    rating INT NOT NULL,
    comments TEXT,
    submitted_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    CHECK (rating BETWEEN 1 AND 5),
    FOREIGN KEY (session_id) REFERENCES mentorship_sessions(session_id) ON DELETE CASCADE,
    FOREIGN KEY (student_id) REFERENCES student_profiles(student_id) ON DELETE CASCADE
);

INSERT INTO courses (course_name) VALUES
('B.Sc Computer Science'), ('B.Sc Information Technology'), ('B.Com'), ('BBA');

INSERT INTO industries (industry_name) VALUES
('Information Technology'), ('Finance'), ('Healthcare'), ('Marketing'), ('Education'), ('Consulting');

INSERT INTO companies (company_name, location, website) VALUES
('Tata Consultancy Services', 'Mumbai', 'https://www.tcs.com'),
('Infosys', 'Pune', 'https://www.infosys.com'),
('Accenture', 'Mumbai', 'https://www.accenture.com'),
('Deloitte', 'Mumbai', 'https://www.deloitte.com');

INSERT INTO skills (skill_name) VALUES
('Java'), ('Python'), ('SQL'), ('Web Development'), ('Cloud Computing'), ('Cybersecurity'), ('Data Science');

INSERT INTO mentorship_topics (topic_name, description) VALUES
('Career Guidance', 'General career planning and industry guidance'),
('Resume Review', 'Guidance for improving resume and profile'),
('Interview Preparation', 'Technical and HR interview preparation'),
('Higher Studies', 'Guidance related to higher education'),
('Technical Guidance', 'Technical learning and career advice'),
('Job Search', 'Guidance for finding suitable job opportunities');

INSERT INTO notification_types (type_name) VALUES
('MENTORSHIP_REQUEST'), ('REQUEST_ACCEPTED'), ('REQUEST_REJECTED'),
('SESSION_BOOKED'), ('SESSION_REMINDER'), ('NEW_MESSAGE');
