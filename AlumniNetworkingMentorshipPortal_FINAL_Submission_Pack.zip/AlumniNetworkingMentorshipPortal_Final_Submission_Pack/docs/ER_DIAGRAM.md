# ER Diagram Specification

17 tables:

1. users
2. courses
3. industries
4. companies
5. student_profiles
6. alumni_profiles
7. skills
8. alumni_skills
9. mentorship_topics
10. mentorship_requests
11. alumni_availability
12. session_time_slots
13. mentorship_sessions
14. messages
15. notification_types
16. notifications
17. session_feedback

## Main relationships

users 1--0/1 student_profiles
users 1--0/1 alumni_profiles
courses 1--N student_profiles
industries 1--N alumni_profiles
companies 1--N alumni_profiles
alumni_profiles N--N skills via alumni_skills
student_profiles 1--N mentorship_requests
alumni_profiles 1--N mentorship_requests
mentorship_topics 1--N mentorship_requests
alumni_profiles 1--N alumni_availability
alumni_availability 1--N session_time_slots
mentorship_requests 1--0/1 mentorship_sessions
session_time_slots 1--0/1 mentorship_sessions
mentorship_sessions 1--0/1 session_feedback
users 1--N messages as sender
users 1--N messages as receiver
users 1--N notifications
notification_types 1--N notifications
