# Final QA & Demo Checklist

## Build verification
- Java source compiled with Java 8 source/target compatibility against Servlet API 4.0.1.
- Result: successful compilation; only standard javac source/target warnings.
- Full Maven/Tomcat/MySQL integration still requires a local configured environment.

## Database verification
The schema contains the required 17 tables:
users, courses, industries, companies, student_profiles, alumni_profiles, skills, alumni_skills, mentorship_topics, mentorship_requests, alumni_availability, session_time_slots, mentorship_sessions, messages, notification_types, notifications, session_feedback.

## Suggested live demo sequence
1. Import `database/schema.sql` into MySQL.
2. Configure database credentials in `DBConnection.java`.
3. Build/deploy the WAR to Tomcat 9.
4. Open `/register-page` and create a STUDENT account.
5. Create an ALUMNI account with industry/company details.
6. Log in as the student and open the alumni directory.
7. Filter/search and open the alumni profile.
8. Send a mentorship request.
9. Log in as the alumni and accept the request.
10. Add availability and create a future time slot.
11. Return to the student account and book the accepted request.
12. Open the session page and demonstrate the generated meeting link.
13. Mark the session completed and submit feedback as the student.
14. Send a message and show the notification list.
15. Keep Tomcat console visible and explain `ReminderThread` as the background thread that checks upcoming sessions and creates reminder notifications.
16. Demonstrate logout and protected-page redirection.
17. Demonstrate a validation/error case and the custom error page.

## CA-II concepts to explain in viva
- Servlet lifecycle: `init()`, `service()`/request handling, `destroy()`.
- `RequestDispatcher.forward()` vs `sendRedirect()`.
- `HttpSession` for login/session tracking and logout invalidation.
- JDBC with `PreparedStatement`.
- Transactional slot booking and rollback.
- Background `ReminderThread` lifecycle and graceful shutdown.
- JSP, JSTL and EL in the view layer.
- DAO pattern and MVC separation.
- Primary/foreign keys and relationships in the 17-table schema.
- Validation and exception handling.
