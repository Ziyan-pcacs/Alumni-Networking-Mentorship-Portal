# CA-II Report Checklist

Cover page
Certificate
Acknowledgement
Declaration of Originality + honest AI disclosure
Index

1. Introduction & Objectives
2. Tools & Technologies Used
3. System Requirements
4. System Design & Architecture
5. Database Design (17 tables + matching SQL)
6. Code Implementation
7. Testing (5-8 cases, including edge case)
8. Real Screenshots (4-6 minimum; more can be included)
9. Deployment & How to Run
10. Conclusion, Learning Outcomes & Future Scope
11. References

Before submission:
- Verify all 17 tables exist in MySQL.
- Verify every documented table matches schema.sql.
- Test Tomcat deployment.
- Test session timeout/logout.
- Test forward() and sendRedirect().
- Test PreparedStatement queries.
- Demonstrate ReminderThread console output.
- Take real screenshots.
- Replace all placeholders.
- Export as RollNo_Name_AJ_CA2_2026-27.pdf.
