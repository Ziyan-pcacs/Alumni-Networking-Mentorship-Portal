# Servlet/JSP Flow

Browser
  -> login.jsp
  -> LoginServlet
  -> UserDAO
  -> MySQL
  -> HttpSession
  -> dashboard.jsp

Student
  -> AlumniSearchServlet
  -> AlumniDAO
  -> MySQL
  -> RequestDispatcher.forward()
  -> alumniSearch.jsp

Successful write operations
  -> DAO
  -> MySQL
  -> response.sendRedirect()

Background
  -> AppContextListener
  -> ReminderThread
  -> check upcoming mentorship sessions
  -> create notifications
