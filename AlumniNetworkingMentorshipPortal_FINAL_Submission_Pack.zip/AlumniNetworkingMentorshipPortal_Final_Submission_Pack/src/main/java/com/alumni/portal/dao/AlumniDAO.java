package com.alumni.portal.dao;

import com.alumni.portal.model.AlumniProfile;
import com.alumni.portal.util.DBConnection;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class AlumniDAO {

    public List<AlumniProfile> search(String industry, Integer year, String skill)
            throws SQLException {

        StringBuilder sql = new StringBuilder(
            "SELECT DISTINCT a.alumni_id, u.user_id, u.name, u.email, " +
            "i.industry_name, c.company_name, a.graduation_year, " +
            "a.designation, a.experience_years, a.bio " +
            "FROM alumni_profiles a " +
            "JOIN users u ON a.user_id = u.user_id " +
            "JOIN industries i ON a.industry_id = i.industry_id " +
            "LEFT JOIN companies c ON a.company_id = c.company_id " +
            "LEFT JOIN alumni_skills aks ON a.alumni_id = aks.alumni_id " +
            "LEFT JOIN skills s ON aks.skill_id = s.skill_id " +
            "WHERE 1=1");

        List<Object> params = new ArrayList<Object>();
        if (industry != null && !industry.trim().isEmpty()) {
            sql.append(" AND i.industry_name = ?");
            params.add(industry.trim());
        }
        if (year != null) {
            sql.append(" AND a.graduation_year = ?");
            params.add(year);
        }
        if (skill != null && !skill.trim().isEmpty()) {
            sql.append(" AND LOWER(s.skill_name) LIKE LOWER(?)");
            params.add("%" + skill.trim() + "%");
        }
        sql.append(" ORDER BY u.name");

        List<AlumniProfile> result = new ArrayList<AlumniProfile>();
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql.toString())) {
            for (int i = 0; i < params.size(); i++) ps.setObject(i + 1, params.get(i));
            try (ResultSet rs = ps.executeQuery()) {
                while (rs.next()) result.add(map(rs));
            }
        }
        return result;
    }

    public AlumniProfile findById(int alumniId) throws SQLException {
        String sql = "SELECT a.alumni_id, u.user_id, u.name, u.email, " +
                "i.industry_name, c.company_name, a.graduation_year, " +
                "a.designation, a.experience_years, a.bio " +
                "FROM alumni_profiles a " +
                "JOIN users u ON a.user_id = u.user_id " +
                "JOIN industries i ON a.industry_id = i.industry_id " +
                "LEFT JOIN companies c ON a.company_id = c.company_id " +
                "WHERE a.alumni_id = ?";
        try (Connection con = DBConnection.getConnection();
             PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setInt(1, alumniId);
            try (ResultSet rs = ps.executeQuery()) {
                return rs.next() ? map(rs) : null;
            }
        }
    }

    private AlumniProfile map(ResultSet rs) throws SQLException {
        AlumniProfile a = new AlumniProfile();
        a.setAlumniId(rs.getInt("alumni_id"));
        a.setUserId(rs.getInt("user_id"));
        a.setName(rs.getString("name"));
        a.setEmail(rs.getString("email"));
        a.setIndustryName(rs.getString("industry_name"));
        a.setCompanyName(rs.getString("company_name"));
        a.setGraduationYear(rs.getInt("graduation_year"));
        a.setDesignation(rs.getString("designation"));
        a.setExperienceYears(rs.getDouble("experience_years"));
        a.setBio(rs.getString("bio"));
        return a;
    }
}
