package com.alumni.portal.dao;

import com.alumni.portal.util.DBConnection;
import java.sql.*;
import java.util.ArrayList;
import java.util.List;

public class MasterDataDAO {
    public List<Option> getCourses() throws SQLException { return getOptions("SELECT course_id AS id, course_name AS name FROM courses ORDER BY course_name"); }
    public List<Option> getIndustries() throws SQLException { return getOptions("SELECT industry_id AS id, industry_name AS name FROM industries ORDER BY industry_name"); }
    public List<Option> getCompanies() throws SQLException { return getOptions("SELECT company_id AS id, company_name AS name FROM companies ORDER BY company_name"); }

    private List<Option> getOptions(String sql) throws SQLException {
        List<Option> list = new ArrayList<>();
        try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(sql); ResultSet rs = ps.executeQuery()) {
            while (rs.next()) list.add(new Option(rs.getInt("id"), rs.getString("name")));
        }
        return list;
    }

    public static class Option {
        private final int id; private final String name;
        public Option(int id, String name) { this.id = id; this.name = name; }
        public int getId() { return id; }
        public String getName() { return name; }
    }
}
