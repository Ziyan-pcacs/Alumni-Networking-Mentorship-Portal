package com.alumni.portal.dao;

import com.alumni.portal.model.User;
import com.alumni.portal.util.DBConnection;

import java.sql.*;

public class UserDAO {

    public User findByEmail(String email) throws SQLException {
        String sql = "SELECT user_id, name, email, password_hash, role FROM users WHERE email = ?";
        try (Connection con = DBConnection.getConnection(); PreparedStatement ps = con.prepareStatement(sql)) {
            ps.setString(1, email);
            try (ResultSet rs = ps.executeQuery()) {
                if (rs.next()) return mapUser(rs);
            }
        }
        return null;
    }

    public int registerStudentTx(String name, String email, String passwordHash,
                                 int courseId, String division, int currentYear,
                                 int graduationYear, String bio) throws SQLException {
        String profileSql = "INSERT INTO student_profiles(user_id,course_id,division,current_year,graduation_year,bio) VALUES(?,?,?,?,?,?)";
        return register(name, email, passwordHash, "STUDENT", profileSql,
                ps -> { ps.setInt(2, courseId); ps.setString(3, division); ps.setInt(4, currentYear); ps.setInt(5, graduationYear); ps.setString(6, bio); });
    }

    public int registerAlumniTx(String name, String email, String passwordHash,
                                 int industryId, Integer companyId, int graduationYear,
                                 String designation, double experienceYears, String bio) throws SQLException {
        String profileSql = "INSERT INTO alumni_profiles(user_id,industry_id,company_id,graduation_year,designation,experience_years,bio) VALUES(?,?,?,?,?,?,?)";
        return register(name, email, passwordHash, "ALUMNI", profileSql,
                ps -> { ps.setInt(2, industryId); if (companyId == null) ps.setNull(3, Types.INTEGER); else ps.setInt(3, companyId); ps.setInt(4, graduationYear); ps.setString(5, designation); ps.setDouble(6, experienceYears); ps.setString(7, bio); });
    }

    @FunctionalInterface
    private interface ProfileBinder { void bind(PreparedStatement ps) throws SQLException; }

    private int register(String name, String email, String passwordHash, String role,
                         String profileSql, ProfileBinder binder) throws SQLException {
        String userSql = "INSERT INTO users(name,email,password_hash,role) VALUES(?,?,?,?)";
        try (Connection con = DBConnection.getConnection()) {
            con.setAutoCommit(false);
            try {
                int userId;
                try (PreparedStatement ps = con.prepareStatement(userSql, Statement.RETURN_GENERATED_KEYS)) {
                    ps.setString(1, name); ps.setString(2, email); ps.setString(3, passwordHash); ps.setString(4, role);
                    ps.executeUpdate();
                    try (ResultSet rs = ps.getGeneratedKeys()) {
                        if (!rs.next()) throw new SQLException("Unable to create user");
                        userId = rs.getInt(1);
                    }
                }
                try (PreparedStatement ps = con.prepareStatement(profileSql)) {
                    ps.setInt(1, userId);
                    binder.bind(ps);
                    ps.executeUpdate();
                }
                con.commit();
                return userId;
            } catch (SQLException e) {
                try { con.rollback(); } catch (SQLException ignored) { }
                throw e;
            } finally {
                try { con.setAutoCommit(true); } catch (SQLException ignored) { }
            }
        }
    }

    private User mapUser(ResultSet rs) throws SQLException {
        User user = new User();
        user.setUserId(rs.getInt("user_id"));
        user.setName(rs.getString("name"));
        user.setEmail(rs.getString("email"));
        user.setPasswordHash(rs.getString("password_hash"));
        user.setRole(rs.getString("role"));
        return user;
    }
}
