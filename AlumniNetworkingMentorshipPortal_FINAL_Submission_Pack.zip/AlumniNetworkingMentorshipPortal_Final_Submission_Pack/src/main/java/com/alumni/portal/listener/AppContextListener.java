package com.alumni.portal.listener;

import com.alumni.portal.thread.ReminderThread;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;
import javax.servlet.annotation.WebListener;

@WebListener
public class AppContextListener implements ServletContextListener {

    private ReminderThread reminderThread;

    @Override
    public void contextInitialized(ServletContextEvent sce) {
        reminderThread = new ReminderThread();
        reminderThread.setName("Mentorship-Reminder-Thread");
        reminderThread.start();
        sce.getServletContext().setAttribute(
            "reminderThread", reminderThread
        );
    }

    @Override
    public void contextDestroyed(ServletContextEvent sce) {
        if (reminderThread != null) {
            reminderThread.stopThread();
        }
    }
}
