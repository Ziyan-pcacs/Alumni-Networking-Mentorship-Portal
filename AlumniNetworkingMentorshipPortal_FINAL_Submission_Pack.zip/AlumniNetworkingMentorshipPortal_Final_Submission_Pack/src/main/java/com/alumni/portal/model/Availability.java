package com.alumni.portal.model;
import java.sql.Time;
public class Availability { private int availabilityId, alumniId; private String dayOfWeek; private Time startTime,endTime; private boolean available;
 public int getAvailabilityId(){return availabilityId;} public void setAvailabilityId(int v){availabilityId=v;} public int getAlumniId(){return alumniId;} public void setAlumniId(int v){alumniId=v;} public String getDayOfWeek(){return dayOfWeek;} public void setDayOfWeek(String v){dayOfWeek=v;} public Time getStartTime(){return startTime;} public void setStartTime(Time v){startTime=v;} public Time getEndTime(){return endTime;} public void setEndTime(Time v){endTime=v;} public boolean isAvailable(){return available;} public void setAvailable(boolean v){available=v;}}
