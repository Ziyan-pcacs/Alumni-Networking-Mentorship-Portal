package com.alumni.portal.model;
import java.sql.Timestamp;
public class Feedback { private int feedbackId,sessionId,studentId,rating; private String comments; private Timestamp submittedAt;
 public int getFeedbackId(){return feedbackId;} public void setFeedbackId(int v){feedbackId=v;} public int getSessionId(){return sessionId;} public void setSessionId(int v){sessionId=v;} public int getStudentId(){return studentId;} public void setStudentId(int v){studentId=v;} public int getRating(){return rating;} public void setRating(int v){rating=v;} public String getComments(){return comments;} public void setComments(String v){comments=v;} public Timestamp getSubmittedAt(){return submittedAt;} public void setSubmittedAt(Timestamp v){submittedAt=v;} }
