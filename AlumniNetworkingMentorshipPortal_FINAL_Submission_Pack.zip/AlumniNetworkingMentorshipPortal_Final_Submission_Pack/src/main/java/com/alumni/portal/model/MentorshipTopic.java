package com.alumni.portal.model;
public class MentorshipTopic { private int topicId; private String topicName; private String description;
 public int getTopicId(){return topicId;} public void setTopicId(int v){topicId=v;} public String getTopicName(){return topicName;} public void setTopicName(String v){topicName=v;} public String getDescription(){return description;} public void setDescription(String v){description=v;}}
