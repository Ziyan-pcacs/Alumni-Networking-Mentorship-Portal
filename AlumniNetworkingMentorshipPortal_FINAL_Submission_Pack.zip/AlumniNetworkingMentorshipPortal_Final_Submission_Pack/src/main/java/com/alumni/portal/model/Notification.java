package com.alumni.portal.model;
import java.sql.Timestamp;
public class Notification { private int notificationId; private String typeName,message; private boolean read; private Timestamp createdAt;
 public int getNotificationId(){return notificationId;} public void setNotificationId(int v){notificationId=v;} public String getTypeName(){return typeName;} public void setTypeName(String v){typeName=v;} public String getMessage(){return message;} public void setMessage(String v){message=v;} public boolean isRead(){return read;} public void setRead(boolean v){read=v;} public Timestamp getCreatedAt(){return createdAt;} public void setCreatedAt(Timestamp v){createdAt=v;} }
