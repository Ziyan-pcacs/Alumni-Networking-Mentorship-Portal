package com.alumni.portal.model;
import java.sql.Date; import java.sql.Time;
public class TimeSlot { private int slotId, availabilityId; private Date slotDate; private Time startTime,endTime; private String status;
 public int getSlotId(){return slotId;} public void setSlotId(int v){slotId=v;} public int getAvailabilityId(){return availabilityId;} public void setAvailabilityId(int v){availabilityId=v;} public Date getSlotDate(){return slotDate;} public void setSlotDate(Date v){slotDate=v;} public Time getStartTime(){return startTime;} public void setStartTime(Time v){startTime=v;} public Time getEndTime(){return endTime;} public void setEndTime(Time v){endTime=v;} public String getStatus(){return status;} public void setStatus(String v){status=v;}}
