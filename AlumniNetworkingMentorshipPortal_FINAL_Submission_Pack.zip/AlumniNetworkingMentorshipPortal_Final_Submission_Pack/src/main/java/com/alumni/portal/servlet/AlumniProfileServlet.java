package com.alumni.portal.servlet;

import com.alumni.portal.dao.AlumniDAO;
import com.alumni.portal.dao.MentorshipDAO;
import com.alumni.portal.model.AlumniProfile;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/alumniProfile")
public class AlumniProfileServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String idText = request.getParameter("id");
        try {
            int id = Integer.parseInt(idText);
            AlumniProfile profile = new AlumniDAO().findById(id);
            if (profile == null) {
                response.sendError(HttpServletResponse.SC_NOT_FOUND, "Alumni profile not found");
                return;
            }
            request.setAttribute("alumni", profile);
            request.setAttribute("topics", new MentorshipDAO().topics());
            request.getRequestDispatcher("/alumniProfile.jsp").forward(request, response);
        } catch (NumberFormatException e) {
            response.sendError(HttpServletResponse.SC_BAD_REQUEST, "Invalid alumni id");
        } catch (SQLException e) {
            getServletContext().log("Alumni profile error", e);
            request.setAttribute("error", "Unable to load alumni profile.");
            request.getRequestDispatcher("/error.jsp").forward(request, response);
        }
    }
}
