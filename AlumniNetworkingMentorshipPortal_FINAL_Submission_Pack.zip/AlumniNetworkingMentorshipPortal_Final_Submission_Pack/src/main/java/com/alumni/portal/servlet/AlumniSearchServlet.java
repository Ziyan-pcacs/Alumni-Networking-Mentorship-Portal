package com.alumni.portal.servlet;

import com.alumni.portal.dao.AlumniDAO;
import com.alumni.portal.dao.MasterDataDAO;
import com.alumni.portal.model.AlumniProfile;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;
import java.util.List;

@WebServlet("/searchAlumni")
public class AlumniSearchServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        String industry = request.getParameter("industry");
        String yearText = request.getParameter("graduationYear");
        String skill = request.getParameter("skill");
        Integer year = null;

        if (yearText != null && !yearText.trim().isEmpty()) {
            try { year = Integer.valueOf(yearText); }
            catch (NumberFormatException e) {
                request.setAttribute("error", "Graduation year must be numeric.");
            }
        }

        try {
            MasterDataDAO master = new MasterDataDAO();
            request.setAttribute("industries", master.getIndustries());
            List<AlumniProfile> alumni = new AlumniDAO().search(industry, year, skill);
            request.setAttribute("alumniList", alumni);
            request.getRequestDispatcher("/alumniSearch.jsp").forward(request, response);
        } catch (SQLException e) {
            getServletContext().log("Alumni search error", e);
            request.setAttribute("error", "Unable to load alumni. Check the database connection.");
            request.getRequestDispatcher("/error.jsp").forward(request, response);
        }
    }
}
