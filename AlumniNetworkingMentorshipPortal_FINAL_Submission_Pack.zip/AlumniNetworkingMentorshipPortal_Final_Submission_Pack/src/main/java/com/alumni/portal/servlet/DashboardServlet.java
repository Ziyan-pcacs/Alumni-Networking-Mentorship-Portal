package com.alumni.portal.servlet;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;

@WebServlet("/dashboard")
public class DashboardServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        String role = (String) request.getSession().getAttribute("role");
        if ("ALUMNI".equals(role)) request.getRequestDispatcher("/alumniDashboard.jsp").forward(request, response);
        else request.getRequestDispatcher("/studentDashboard.jsp").forward(request, response);
    }
}
