package com.alumni.portal.servlet;

import com.alumni.portal.dao.UserDAO;
import com.alumni.portal.model.User;
import com.alumni.portal.util.PasswordUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/login")
public class LoginServlet extends HttpServlet {

    @Override
    protected void doPost(HttpServletRequest request,
                           HttpServletResponse response)
            throws ServletException, IOException {

        String email = request.getParameter("email");
        String password = request.getParameter("password");

        if (email == null || email.trim().isEmpty()
                || password == null || password.isEmpty()) {
            request.setAttribute("error", "Email and password are required.");
            request.getRequestDispatcher("/login.jsp")
                   .forward(request, response);
            return;
        }

        try {
            User user = new UserDAO().findByEmail(email.trim());

            if (user != null &&
                PasswordUtil.verify(password, user.getPasswordHash())) {

                HttpSession session = request.getSession(true);
                session.setMaxInactiveInterval(30 * 60);
                session.setAttribute("userId", user.getUserId());
                session.setAttribute("userName", user.getName());
                session.setAttribute("role", user.getRole());

                response.sendRedirect(request.getContextPath() + "/dashboard");
            } else {
                request.setAttribute("error", "Invalid email or password.");
                request.getRequestDispatcher("/login.jsp")
                       .forward(request, response);
            }

        } catch (SQLException e) {
            getServletContext().log("Login database error", e);
            request.setAttribute("error", "A database error occurred.");
            request.getRequestDispatcher("/error.jsp")
                   .forward(request, response);
        }
    }
}
