package com.alumni.portal.servlet;

import com.alumni.portal.dao.MasterDataDAO;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/register-page")
public class RegisterPageServlet extends HttpServlet {
    @Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        try {
            MasterDataDAO dao = new MasterDataDAO();
            request.setAttribute("courses", dao.getCourses());
            request.setAttribute("industries", dao.getIndustries());
            request.setAttribute("companies", dao.getCompanies());
            request.getRequestDispatcher("/register.jsp").forward(request, response);
        } catch (SQLException e) {
            getServletContext().log("Master data load error", e);
            request.setAttribute("error", "Unable to load registration data. Check the database connection.");
            request.getRequestDispatcher("/error.jsp").forward(request, response);
        }
    }
}
