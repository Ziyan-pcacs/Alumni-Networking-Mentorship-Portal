package com.alumni.portal.servlet;

import com.alumni.portal.dao.MasterDataDAO;
import com.alumni.portal.dao.UserDAO;
import com.alumni.portal.util.PasswordUtil;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.*;
import java.io.IOException;
import java.sql.SQLException;

@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
    @Override
    protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
        request.setCharacterEncoding("UTF-8");
        String name = trim(request.getParameter("name"));
        String email = trim(request.getParameter("email"));
        String password = request.getParameter("password");
        String confirm = request.getParameter("confirmPassword");
        String role = trim(request.getParameter("role"));

        if (name.isEmpty() || email.isEmpty() || password == null || password.length() < 8 || !password.equals(confirm)
                || !("STUDENT".equals(role) || "ALUMNI".equals(role))) {
            fail(request, response, "Enter valid details. Password must be at least 8 characters and both passwords must match.");
            return;
        }

        try {
            UserDAO dao = new UserDAO();
            String hash = PasswordUtil.hash(password);
            if ("STUDENT".equals(role)) {
                int courseId = Integer.parseInt(request.getParameter("courseId"));
                int currentYear = Integer.parseInt(request.getParameter("currentYear"));
                int graduationYear = Integer.parseInt(request.getParameter("graduationYear"));
                dao.registerStudentTx(name, email, hash, courseId, trim(request.getParameter("division")), currentYear, graduationYear, trim(request.getParameter("bio")));
            } else {
                int industryId = Integer.parseInt(request.getParameter("industryId"));
                String company = trim(request.getParameter("companyId"));
                Integer companyId = company.isEmpty() ? null : Integer.valueOf(company);
                int graduationYear = Integer.parseInt(request.getParameter("alumniGraduationYear"));
                double experience = Double.parseDouble(request.getParameter("experienceYears"));
                dao.registerAlumniTx(name, email, hash, industryId, companyId, graduationYear, trim(request.getParameter("designation")), experience, trim(request.getParameter("alumniBio")));
            }
            response.sendRedirect(request.getContextPath() + "/login.jsp?registered=1");
        } catch (NumberFormatException e) {
            fail(request, response, "Please enter valid numeric profile details.");
        } catch (SQLException e) {
            getServletContext().log("Registration database error", e);
            if (e.getMessage() != null && e.getMessage().toLowerCase().contains("duplicate"))
                fail(request, response, "That email address is already registered.");
            else
                fail(request, response, "Registration failed. Check the database connection and try again.");
        }
    }

    private void fail(HttpServletRequest req, HttpServletResponse resp, String message) throws ServletException, IOException {
        try {
            MasterDataDAO dao = new MasterDataDAO();
            req.setAttribute("courses", dao.getCourses());
            req.setAttribute("industries", dao.getIndustries());
            req.setAttribute("companies", dao.getCompanies());
        } catch (SQLException ignored) { }
        req.setAttribute("error", message);
        req.getRequestDispatcher("/register.jsp").forward(req, resp);
    }
    private String trim(String value) { return value == null ? "" : value.trim(); }
}
