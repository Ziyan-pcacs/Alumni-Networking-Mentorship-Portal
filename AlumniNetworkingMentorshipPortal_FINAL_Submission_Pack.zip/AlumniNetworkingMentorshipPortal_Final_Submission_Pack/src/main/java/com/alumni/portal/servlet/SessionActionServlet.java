package com.alumni.portal.servlet;
import com.alumni.portal.dao.CommunicationDAO; import com.alumni.portal.dao.MentorshipDAO; import javax.servlet.*; import javax.servlet.http.*; import javax.servlet.annotation.*; import java.io.IOException;
@WebServlet("/session-action") public class SessionActionServlet extends HttpServlet{
 private final CommunicationDAO comm=new CommunicationDAO(); private final MentorshipDAO mentorship=new MentorshipDAO();
 protected void doPost(HttpServletRequest req,HttpServletResponse res)throws ServletException,IOException{try{HttpSession s=req.getSession(false);int uid=(Integer)s.getAttribute("userId");String action=req.getParameter("action");int sid=Integer.parseInt(req.getParameter("sessionId"));boolean ok=false;if("complete".equals(action))ok=comm.completeSession(sid,uid);else if("feedback".equals(action)){int student=mentorship.studentIdByUser(uid);int rating=Integer.parseInt(req.getParameter("rating"));ok=comm.addFeedback(sid,student,rating,req.getParameter("comments"));}res.sendRedirect(req.getContextPath()+"/mentorship?result="+(ok?"success":"failed"));}catch(Exception e){throw new ServletException(e);}}
}
