package com.alumni.portal.thread;
import com.alumni.portal.dao.CommunicationDAO;
import java.util.concurrent.atomic.AtomicBoolean;
public class ReminderThread extends Thread {
 private final AtomicBoolean running=new AtomicBoolean(true); private final CommunicationDAO dao=new CommunicationDAO();
 @Override public void run(){System.out.println("[ReminderThread] Started.");while(running.get()){try{System.out.println("[ReminderThread] Checking sessions within next 24 hours...");dao.createReminderNotifications();System.out.println("[ReminderThread] Reminder check completed.");Thread.sleep(30000L);}catch(InterruptedException e){Thread.currentThread().interrupt();break;}catch(Exception e){System.err.println("[ReminderThread] Error: "+e.getMessage());}}System.out.println("[ReminderThread] Stopped.");}
 public void stopThread(){running.set(false);interrupt();}
}
