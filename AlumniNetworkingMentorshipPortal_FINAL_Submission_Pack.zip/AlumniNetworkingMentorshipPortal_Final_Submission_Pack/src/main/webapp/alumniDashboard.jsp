<%@ page contentType="text/html;charset=UTF-8" %>
<!DOCTYPE html>
<html><head>
<link rel="stylesheet" href="${pageContext.request.contextPath}/css/app.css"><title>Alumni Dashboard</title></head><body>
<h1>Alumni Dashboard</h1>
<h2>Welcome, ${sessionScope.userName}</h2>
<p>Your role: ${sessionScope.role}</p>
<ul>
<li>Manage mentorship requests — coming in the next module</li>
<li>Manage availability — coming in the next module</li>
<li><a href="${pageContext.request.contextPath}/searchAlumni">Browse alumni directory</a></li>
<li><a href="${pageContext.request.contextPath}/logout">Logout</a></li>
</ul>
<p><a href="${pageContext.request.contextPath}/mentorship">Mentorship Center</a></p><p><a href="${pageContext.request.contextPath}/communication">Messages & Notifications</a></p></body></html>
