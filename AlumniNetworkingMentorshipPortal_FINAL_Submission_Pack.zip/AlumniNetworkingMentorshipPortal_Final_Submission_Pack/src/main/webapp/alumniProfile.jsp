<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="${pageContext.request.contextPath}/css/app.css">
    <title>${alumni.name} | Alumni Profile</title>
    <style>
        body{font-family:Arial,sans-serif;background:#f4f7fb;margin:0;color:#1f2937}.wrap{max-width:800px;margin:50px auto;padding:20px}.card{background:white;border-radius:16px;padding:32px;box-shadow:0 5px 20px rgba(0,0,0,.08)}.tag{display:inline-block;background:#eef2ff;padding:7px 12px;border-radius:20px;margin:4px}.row{padding:12px 0;border-bottom:1px solid #eee}.label{font-size:12px;color:#6b7280;text-transform:uppercase}.value{font-size:17px;margin-top:4px}a{color:#2563eb;text-decoration:none}
    </style>
</head>
<body>
<div class="wrap">
<div class="card">
    <h1>${alumni.name}</h1>
    <p>${alumni.designation} · ${alumni.industryName}</p>
    <div class="row"><div class="label">Company</div><div class="value">${empty alumni.companyName ? 'Not specified' : alumni.companyName}</div></div>
    <div class="row"><div class="label">Graduation Year</div><div class="value">${alumni.graduationYear}</div></div>
    <div class="row"><div class="label">Experience</div><div class="value">${alumni.experienceYears} years</div></div>
    <div class="row"><div class="label">About</div><div class="value">${empty alumni.bio ? 'No biography added yet.' : alumni.bio}</div></div>
    <div class="row"><div class="label">Contact</div><div class="value">${alumni.email}</div></div>
    <c:if test="${sessionScope.role == 'STUDENT'}">
    <div class="row"><div class="label">Request Mentorship</div><form method="post" action="${pageContext.request.contextPath}/mentorship">
    <input type="hidden" name="action" value="request"><input type="hidden" name="alumniId" value="${alumni.alumniId}">
    <select name="topicId" required><option value="">Select topic</option><c:forEach var="t" items="${topics}"><option value="${t.topicId}">${t.topicName}</option></c:forEach></select><br>
    <textarea name="message" rows="4" style="width:100%;margin-top:8px" placeholder="Briefly explain what guidance you need" required></textarea><br><button type="submit">Send Mentorship Request</button></form></div>
    </c:if>
    <br>
    <a href="${pageContext.request.contextPath}/searchAlumni">← Back to Alumni Directory</a>
</div>
</div>
</body>
</html>
