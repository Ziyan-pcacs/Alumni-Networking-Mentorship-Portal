<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="${pageContext.request.contextPath}/css/app.css">
    <title>Find Alumni | Alumni Mentorship Portal</title>
    <style>
        body{font-family:Arial,sans-serif;background:#f4f7fb;margin:0;color:#1f2937}
        .wrap{max-width:1050px;margin:40px auto;padding:0 20px}
        .card{background:#fff;border-radius:14px;padding:24px;margin-bottom:20px;box-shadow:0 5px 20px rgba(0,0,0,.07)}
        .filters{display:grid;grid-template-columns:1fr 1fr 1fr auto;gap:12px;align-items:end}
        label{font-size:13px;font-weight:bold;display:block;margin-bottom:6px}
        input,select,button{width:100%;padding:11px;border:1px solid #d1d5db;border-radius:8px;box-sizing:border-box}
        button{background:#2563eb;color:white;border:0;font-weight:bold;cursor:pointer}
        table{width:100%;border-collapse:collapse} th,td{padding:13px;border-bottom:1px solid #e5e7eb;text-align:left} th{background:#f8fafc}
        a{color:#2563eb;text-decoration:none}.empty{padding:25px;text-align:center;color:#6b7280}
    </style>
</head>
<body>
<div class="wrap">
    <div class="card">
        <h1>Find Alumni &amp; Mentors</h1>
        <p>Search alumni by industry, graduation year, or skill.</p>
        <form method="get" action="${pageContext.request.contextPath}/searchAlumni" class="filters">
            <div>
                <label>Industry</label>
                <select name="industry">
                    <option value="">All industries</option>
                    <c:forEach var="item" items="${industries}">
                        <option value="${item.name}" ${param.industry == item.name ? 'selected' : ''}>${item.name}</option>
                    </c:forEach>
                </select>
            </div>
            <div>
                <label>Graduation Year</label>
                <input type="number" name="graduationYear" value="${param.graduationYear}" placeholder="e.g. 2022">
            </div>
            <div>
                <label>Skill</label>
                <input type="text" name="skill" value="${param.skill}" placeholder="e.g. Java">
            </div>
            <button type="submit">Search</button>
        </form>
    </div>

    <div class="card">
        <c:if test="${not empty error}"><p><strong>${error}</strong></p></c:if>
        <c:choose>
            <c:when test="${not empty alumniList}">
                <h2>${alumniList.size()} alumni found</h2>
                <table>
                    <tr><th>Name</th><th>Industry</th><th>Company</th><th>Graduation</th><th>Designation</th><th></th></tr>
                    <c:forEach var="alumni" items="${alumniList}">
                        <tr>
                            <td>${alumni.name}</td>
                            <td>${alumni.industryName}</td>
                            <td>${empty alumni.companyName ? '—' : alumni.companyName}</td>
                            <td>${alumni.graduationYear}</td>
                            <td>${alumni.designation}</td>
                            <td><a href="${pageContext.request.contextPath}/alumniProfile?id=${alumni.alumniId}">View Profile</a></td>
                        </tr>
                    </c:forEach>
                </table>
            </c:when>
            <c:otherwise>
                <div class="empty">No alumni found for the selected filters.</div>
            </c:otherwise>
        </c:choose>
    </div>
    <p><a href="${pageContext.request.contextPath}/dashboard">← Back to Dashboard</a></p>
</div>
</body>
</html>
