<%@ page contentType="text/html;charset=UTF-8" %>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="${pageContext.request.contextPath}/css/app.css">
    <title>Error</title>
</head>
<body>
<h1>Something went wrong</h1>
<p>${error}</p>
<a href="${pageContext.request.contextPath}/login.jsp">Return to Login</a>
</body>
</html>
