<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html><head>
<link rel="stylesheet" href="${pageContext.request.contextPath}/css/app.css"><title>Alumni Portal - Login</title></head><body>
<h1>Alumni Networking &amp; Mentorship Portal</h1>
<c:if test="${param.registered == '1'}"><p><strong>Registration successful. Please login.</strong></p></c:if>
<c:if test="${param.loginRequired == '1'}"><p><strong>Please login to continue.</strong></p></c:if>
<c:if test="${not empty error}"><p><strong>${error}</strong></p></c:if>
<form method="post" action="${pageContext.request.contextPath}/login">
<label>Email:</label><input type="email" name="email" required><br><br>
<label>Password:</label><input type="password" name="password" required><br><br>
<button type="submit">Login</button>
</form>
<p><a href="${pageContext.request.contextPath}/register-page">Create a new account</a></p>
</body></html>
