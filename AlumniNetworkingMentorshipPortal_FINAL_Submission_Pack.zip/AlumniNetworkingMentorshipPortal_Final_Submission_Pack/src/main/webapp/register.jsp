<%@ page contentType="text/html;charset=UTF-8" %>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
<link rel="stylesheet" href="${pageContext.request.contextPath}/css/app.css"><title>Register - Alumni Portal</title></head>
<body>
<h1>Create Portal Account</h1>
<c:if test="${not empty error}"><p><strong>${error}</strong></p></c:if>
<form method="post" action="${pageContext.request.contextPath}/register">
    <label>Full Name</label><input type="text" name="name" required><br><br>
    <label>Email</label><input type="email" name="email" required><br><br>
    <label>Password</label><input type="password" name="password" minlength="8" required><br><br>
    <label>Confirm Password</label><input type="password" name="confirmPassword" minlength="8" required><br><br>
    <label>Role</label>
    <select name="role" id="role" onchange="toggleRoleFields()" required>
        <option value="">Select role</option><option value="STUDENT">Student</option><option value="ALUMNI">Alumni</option>
    </select><br><br>

    <fieldset id="studentFields" style="display:none">
        <legend>Student Profile</legend>
        <label>Course</label><select name="courseId"><c:forEach var="x" items="${courses}"><option value="${x.id}">${x.name}</option></c:forEach></select><br><br>
        <label>Division</label><input type="text" name="division"><br><br>
        <label>Current Year</label><input type="number" name="currentYear" min="1" max="4"><br><br>
        <label>Graduation Year</label><input type="number" name="graduationYear" min="2020" max="2040"><br><br>
        <label>Bio</label><textarea name="bio"></textarea>
    </fieldset>

    <fieldset id="alumniFields" style="display:none">
        <legend>Alumni Profile</legend>
        <label>Industry</label><select name="industryId"><c:forEach var="x" items="${industries}"><option value="${x.id}">${x.name}</option></c:forEach></select><br><br>
        <label>Company</label><select name="companyId"><option value="">Not specified</option><c:forEach var="x" items="${companies}"><option value="${x.id}">${x.name}</option></c:forEach></select><br><br>
        <label>Graduation Year</label><input type="number" name="alumniGraduationYear" min="1970" max="2040"><br><br>
        <label>Designation</label><input type="text" name="designation"><br><br>
        <label>Experience (years)</label><input type="number" step="0.5" min="0" name="experienceYears"><br><br>
        <label>Bio</label><textarea name="alumniBio"></textarea>
    </fieldset>
    <br><button type="submit">Create Account</button>
</form>
<p><a href="${pageContext.request.contextPath}/login.jsp">Already have an account? Login</a></p>
<script>
function toggleRoleFields(){
 const role=document.getElementById('role').value;
 document.getElementById('studentFields').style.display=role==='STUDENT'?'block':'none';
 document.getElementById('alumniFields').style.display=role==='ALUMNI'?'block':'none';
}
</script>
</body></html>
