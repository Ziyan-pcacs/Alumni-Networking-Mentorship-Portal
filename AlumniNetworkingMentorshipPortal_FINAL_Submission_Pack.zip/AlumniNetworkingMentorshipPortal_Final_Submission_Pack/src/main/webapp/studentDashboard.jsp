<%@ page contentType="text/html;charset=UTF-8" %>
<!DOCTYPE html>
<html><head>
<link rel="stylesheet" href="${pageContext.request.contextPath}/css/app.css"><title>Student Dashboard</title></head><body>
<h1>Student Dashboard</h1>
<h2>Welcome, ${sessionScope.userName}</h2>
<p>Your role: ${sessionScope.role}</p>
<ul>
<li><a href="${pageContext.request.contextPath}/searchAlumni">Find Alumni &amp; Mentors</a></li>
<li><a href="${pageContext.request.contextPath}/logout">Logout</a></li>
</ul>
<p><a href="${pageContext.request.contextPath}/mentorship">Mentorship Center</a></p><p><a href="${pageContext.request.contextPath}/communication">Messages & Notifications</a></p></body></html>
